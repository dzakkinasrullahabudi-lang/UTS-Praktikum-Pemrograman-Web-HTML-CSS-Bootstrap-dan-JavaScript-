const questions = [
    {
        question: "Apa fungsi utama HTML dalam sebuah halaman web?",
        options: [
            "Mengatur struktur dan isi halaman",
            "Menyimpan data ke database",
            "Mengatur warna dan tata letak saja",
            "Menjalankan server web"
        ],
        answer: 0,
        explanation: "HTML menyusun struktur dan konten halaman, misalnya judul, paragraf, gambar, tautan, dan formulir."
    },
    {
        question: "Atribut HTML apa yang digunakan untuk memberi alamat tujuan pada tautan?",
        options: ["src", "href", "alt", "target"],
        answer: 1,
        explanation: "Atribut href pada elemen tautan berisi alamat halaman atau sumber yang dituju."
    },
    {
        question: "Apa kegunaan CSS?",
        options: [
            "Menentukan struktur data JavaScript",
            "Menghubungkan halaman ke database",
            "Mengatur tampilan dan tata letak halaman",
            "Mengirim formulir ke server secara otomatis"
        ],
        answer: 2,
        explanation: "CSS mengatur presentasi halaman, termasuk warna, tipografi, jarak, dan tata letak."
    },
    {
        question: "Deklarasi CSS apa yang umum digunakan untuk membuat elemen menjadi flex container?",
        options: [
            "position: flex",
            "display: flex",
            "flex: display",
            "layout: flex"
        ],
        answer: 1,
        explanation: "Deklarasi display: flex mengaktifkan Flexbox pada sebuah elemen."
    },
    {
        question: "Apa tujuan media query dalam CSS?",
        options: [
            "Menjalankan JavaScript saat halaman dimuat",
            "Mengubah tampilan berdasarkan kondisi perangkat atau layar",
            "Membuat tabel HTML secara otomatis",
            "Mengambil gambar dari internet"
        ],
        answer: 1,
        explanation: "Media query menerapkan aturan CSS berdasarkan kondisi seperti lebar layar agar tata letak responsif."
    },
    {
        question: "Bagaimana Bootstrap dapat ditambahkan ke halaman web?",
        options: [
            "Dengan mengimpor berkas PDF",
            "Dengan menulis ulang seluruh Bootstrap di dalam HTML",
            "Dengan memuat CSS dan JavaScript Bootstrap melalui CDN",
            "Dengan mengganti HTML menggunakan JavaScript"
        ],
        answer: 2,
        explanation: "Bootstrap dapat dimuat dari CDN menggunakan elemen link untuk CSS dan script bundle untuk komponennya."
    },
    {
        question: "Dalam grid Bootstrap, apa peran class row?",
        options: [
            "Menjadi wadah baris bagi kolom-kolom grid",
            "Mengubah halaman menjadi formulir",
            "Membuat tombol navigasi",
            "Menambahkan validasi email"
        ],
        answer: 0,
        explanation: "Class row membungkus kolom Bootstrap dan membantu mengatur grid serta jarak antarkolom."
    },
    {
        question: "Kata kunci JavaScript mana yang cocok untuk variabel yang tidak akan ditugaskan ulang?",
        options: ["var", "const", "static", "fixed"],
        answer: 1,
        explanation: "const mencegah variabel ditugaskan ulang. Isi object atau array yang dideklarasikan dengan const masih dapat diubah."
    },
    {
        question: "Method apa yang umum dipakai untuk memasang event handler pada elemen DOM?",
        options: [
            "addEventListener()",
            "createEventHandler()",
            "appendListener()",
            "setEvent()"
        ],
        answer: 0,
        explanation: "addEventListener() memasang fungsi penanganan untuk event tertentu, misalnya click, change, atau submit."
    },
    {
        question: "Apa tujuan event.preventDefault() saat menangani pengiriman form?",
        options: [
            "Menghapus semua kolom formulir",
            "Menghentikan perilaku bawaan browser agar form dapat diproses dengan JavaScript",
            "Menambahkan class Bootstrap ke setiap elemen",
            "Memuat ulang halaman dengan paksa"
        ],
        answer: 1,
        explanation: "preventDefault() membatalkan perilaku standar event. Pada submit, ini mencegah halaman berpindah atau dimuat ulang sebelum JavaScript memproses jawaban."
    }
];

const quizForm = document.getElementById("formKuis");
const questionArea = document.getElementById("areaPertanyaan");
const questionNumber = document.getElementById("nomorSoal");
const progressBar = document.getElementById("progressKuis");
const progressContainer = document.getElementById("wadahProgress");
const quizMessage = document.getElementById("pesanKuis");
const previousButton = document.getElementById("tombolSebelumnya");
const nextButton = document.getElementById("tombolBerikutnya");
const resultSection = document.getElementById("hasilKuis");
const scoreDisplay = document.getElementById("skorAkhir");
const resultMessage = document.getElementById("pesanHasil");
const discussionList = document.getElementById("daftarPembahasan");
const restartButton = document.getElementById("tombolUlangi");

let currentQuestionIndex = 0;
let selectedAnswers = new Array(questions.length).fill(null);

// Menampilkan satu soal dan jawaban yang sudah tersimpan untuk soal itu.
function renderQuestion() {
    const currentQuestion = questions[currentQuestionIndex];
    const fieldset = document.createElement("fieldset");
    const legend = document.createElement("legend");
    const choices = document.createElement("div");
    const validationMessage = document.createElement("div");

    legend.className = "question-title mb-3";
    legend.textContent = currentQuestion.question;
    choices.id = "pilihanJawaban";

    for (let index = 0; index < currentQuestion.options.length; index++) {
        const label = document.createElement("label");
        const input = document.createElement("input");
        const optionText = document.createElement("span");

        label.className = "form-check answer-option d-flex align-items-start gap-2";
        input.className = "form-check-input flex-shrink-0 mt-1";
        input.type = "radio";
        input.name = "jawaban";
        input.value = String(index);
        input.checked = selectedAnswers[currentQuestionIndex] === index;
        optionText.textContent = currentQuestion.options[index];

        label.append(input, optionText);
        choices.append(label);
    }

    validationMessage.id = "pesanValidasi";
    validationMessage.className = "invalid-feedback d-none";
    validationMessage.textContent = "Pilih satu jawaban sebelum melanjutkan.";

    fieldset.append(legend, choices, validationMessage);
    questionArea.replaceChildren(fieldset);

    questionNumber.textContent = `Soal ${currentQuestionIndex + 1} dari ${questions.length}`;
    const progress = (currentQuestionIndex / questions.length) * 100;
    progressBar.style.width = `${progress}%`;
    progressContainer.setAttribute("aria-valuenow", String(progress));
    previousButton.disabled = currentQuestionIndex === 0;
    nextButton.textContent = currentQuestionIndex === questions.length - 1
        ? "Lihat Hasil"
        : "Berikutnya";
    clearQuizMessage();
}

// Menghapus tanda validasi setelah pengguna memilih jawaban.
function handleAnswerChange(event) {
    if (event.target.name !== "jawaban") {
        return;
    }

    selectedAnswers[currentQuestionIndex] = Number(event.target.value);

    const answerInputs = questionArea.querySelectorAll('input[name="jawaban"]');
    for (const input of answerInputs) {
        input.classList.remove("is-invalid");
    }

    const validationMessage = document.getElementById("pesanValidasi");
    validationMessage.classList.remove("d-block");
    validationMessage.classList.add("d-none");
    clearQuizMessage();
}

// Memvalidasi jawaban, menyimpannya, lalu berpindah soal atau menampilkan hasil.
function handleQuizSubmit(event) {
    event.preventDefault();

    const selectedInput = questionArea.querySelector('input[name="jawaban"]:checked');
    if (!selectedInput) {
        const answerInputs = questionArea.querySelectorAll('input[name="jawaban"]');
        for (const input of answerInputs) {
            input.classList.add("is-invalid");
        }

        const validationMessage = document.getElementById("pesanValidasi");
        validationMessage.classList.remove("d-none");
        validationMessage.classList.add("d-block");
        showQuizMessage("Pilih satu jawaban terlebih dahulu.", "warning");
        return;
    }

    selectedAnswers[currentQuestionIndex] = Number(selectedInput.value);
    currentQuestionIndex++;

    if (currentQuestionIndex === questions.length) {
        showResults();
        return;
    }

    renderQuestion();
}

// Kembali ke soal sebelumnya tanpa menghapus jawaban yang tersimpan.
function handlePreviousQuestion() {
    if (currentQuestionIndex === 0) {
        return;
    }

    currentQuestionIndex--;
    renderQuestion();
}

// Menampilkan pesan status melalui komponen alert Bootstrap.
function showQuizMessage(message, type) {
    quizMessage.textContent = message;
    quizMessage.className = `alert alert-${type}`;
}

// Menyembunyikan alert status kuis.
function clearQuizMessage() {
    quizMessage.textContent = "";
    quizMessage.className = "alert d-none";
}

// Membuat item accordion untuk jawaban dan pembahasan sebuah soal.
function createDiscussionItem(index) {
    const question = questions[index];
    const selectedAnswer = selectedAnswers[index];
    const isCorrect = selectedAnswer === question.answer;
    const item = document.createElement("div");
    const heading = document.createElement("h5");
    const toggle = document.createElement("button");
    const collapse = document.createElement("div");
    const body = document.createElement("div");
    const questionText = document.createElement("p");
    const yourAnswer = document.createElement("p");
    const correctAnswer = document.createElement("p");
    const explanation = document.createElement("p");

    item.className = "accordion-item";
    heading.className = "accordion-header";
    heading.id = `heading-${index}`;
    toggle.className = `accordion-button ${index === 0 ? "" : "collapsed"}`;
    toggle.type = "button";
    toggle.setAttribute("data-bs-toggle", "collapse");
    toggle.setAttribute("data-bs-target", `#pembahasan-${index}`);
    toggle.setAttribute("aria-expanded", String(index === 0));
    toggle.setAttribute("aria-controls", `pembahasan-${index}`);
    toggle.textContent = `Soal ${index + 1}: ${isCorrect ? "Benar" : "Belum tepat"}`;

    collapse.id = `pembahasan-${index}`;
    collapse.className = `accordion-collapse collapse ${index === 0 ? "show" : ""}`;
    collapse.setAttribute("aria-labelledby", heading.id);
    collapse.setAttribute("data-bs-parent", "#daftarPembahasan");

    body.className = "accordion-body";
    questionText.className = "fw-semibold";
    questionText.textContent = question.question;
    yourAnswer.textContent = `Jawabanmu: ${question.options[selectedAnswer]}`;
    yourAnswer.classList.add(isCorrect ? "text-success" : "text-danger");
    correctAnswer.textContent = `Jawaban benar: ${question.options[question.answer]}`;
    correctAnswer.className = "text-success fw-semibold";
    explanation.className = "mb-0";
    explanation.textContent = question.explanation;

    body.append(questionText, yourAnswer, correctAnswer, explanation);
    collapse.append(body);
    heading.append(toggle);
    item.append(heading, collapse);
    return item;
}

// Menghitung skor akhir dan menampilkan pembahasan semua soal.
function showResults() {
    let score = 0;
    for (let index = 0; index < questions.length; index++) {
        if (selectedAnswers[index] === questions[index].answer) {
            score++;
        }
    }

    const percentage = Math.round((score / questions.length) * 100);
    scoreDisplay.textContent = `${score} dari ${questions.length} (${percentage}%)`;
    resultMessage.textContent = percentage === 100
        ? "Sempurna! Semua jawabanmu benar."
        : "Pelajari pembahasan berikut untuk memperkuat pemahamanmu.";

    discussionList.replaceChildren();
    for (let index = 0; index < questions.length; index++) {
        discussionList.append(createDiscussionItem(index));
    }

    progressBar.style.width = "100%";
    progressContainer.setAttribute("aria-valuenow", "100");
    questionNumber.textContent = "Kuis selesai";
    quizForm.classList.add("d-none");
    resultSection.classList.remove("d-none");
    clearQuizMessage();
}

// Mengulang kuis dengan menghapus jawaban dan mengembalikan tampilan awal.
function restartQuiz() {
    currentQuestionIndex = 0;
    selectedAnswers = new Array(questions.length).fill(null);
    quizForm.reset();
    quizForm.classList.remove("d-none");
    resultSection.classList.add("d-none");
    renderQuestion();
}

quizForm.addEventListener("submit", handleQuizSubmit);
questionArea.addEventListener("change", handleAnswerChange);
previousButton.addEventListener("click", handlePreviousQuestion);
restartButton.addEventListener("click", restartQuiz);

renderQuestion();
