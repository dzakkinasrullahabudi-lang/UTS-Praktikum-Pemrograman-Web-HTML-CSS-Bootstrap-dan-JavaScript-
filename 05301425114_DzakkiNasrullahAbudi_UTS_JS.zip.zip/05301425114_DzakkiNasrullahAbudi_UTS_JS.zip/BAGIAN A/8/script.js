const buku = {
    judul: "Laskar Pelangi",
    penulis: "Andrea Hirata",
    tahun: 2005,
    harga: 100000,
    infoBuku() {
        return `Buku "${this.judul}" ditulis oleh ${this.penulis}, diterbitkan pada tahun ${this.tahun}, dan berharga Rp${this.harga.toLocaleString("id-ID")}.`;
    }
};

document.getElementById("infoBuku").textContent = buku.infoBuku();
