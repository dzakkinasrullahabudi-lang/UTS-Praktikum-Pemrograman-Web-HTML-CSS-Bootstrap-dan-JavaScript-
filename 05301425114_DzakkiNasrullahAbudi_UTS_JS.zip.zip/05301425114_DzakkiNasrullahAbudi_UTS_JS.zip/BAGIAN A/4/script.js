const form = document.getElementById("formPendaftaran");
const nama = document.getElementById("nama");
const email = document.getElementById("email");
const jurusan = document.getElementById("jurusan");
const pesan = document.getElementById("pesan");

form.addEventListener("submit", function(event) {
    event.preventDefault();

    let valid = true;
    const polaEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (nama.value.trim() === "") {
        nama.classList.add("is-invalid");
        valid = false;
    } else {
        nama.classList.remove("is-invalid");
    }

    if (!polaEmail.test(email.value.trim())) {
        email.classList.add("is-invalid");
        valid = false;
    } else {
        email.classList.remove("is-invalid");
    }

    if (jurusan.value === "") {
        jurusan.classList.add("is-invalid");
        valid = false;
    } else {
        jurusan.classList.remove("is-invalid");
    }

    if (valid) {
        pesan.innerHTML = `
            <div class="alert alert-success" role="alert">
                Pendaftaran berhasil! Terima kasih sudah mengisi form.
            </div>
        `;
        form.reset();
    } else {
        pesan.innerHTML = `
            <div class="alert alert-danger" role="alert">
                Periksa kembali data yang kamu masukkan.
            </div>
        `;
    }
});
