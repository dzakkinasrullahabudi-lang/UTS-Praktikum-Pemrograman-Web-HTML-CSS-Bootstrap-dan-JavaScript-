function konversiSuhu() {
    const input = document.getElementById("celsius");
    const hasil = document.getElementById("hasil");

    if (input.value.trim() === "") {
        hasil.innerHTML = "Silakan masukkan suhu Celsius.";
        return;
    }

    const celsius = Number(input.value);
    const fahrenheit = (celsius * 9 / 5) + 32;
    const reamur = celsius * 4 / 5;
    const kelvin = celsius + 273.15;

    hasil.innerHTML = `
        <h3>Hasil Konversi</h3>
        Celsius: ${celsius} °C<br>
        Fahrenheit: ${fahrenheit} °F<br>
        Reamur: ${reamur} °Re<br>
        Kelvin: ${kelvin} K
    `;
}

document.getElementById("tombolKonversi").addEventListener("click", konversiSuhu);
