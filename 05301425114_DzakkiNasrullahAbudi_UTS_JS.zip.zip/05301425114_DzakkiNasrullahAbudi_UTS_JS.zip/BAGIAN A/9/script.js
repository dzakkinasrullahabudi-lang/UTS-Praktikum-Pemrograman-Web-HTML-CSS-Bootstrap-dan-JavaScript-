const paragraf = document.getElementById("paragraf");
const ukuranSemula = 18;
let ukuranHuruf = ukuranSemula;

document.getElementById("perbesar").addEventListener("click", function() {
    ukuranHuruf += 2;
    paragraf.style.fontSize = `${ukuranHuruf}px`;
});

document.getElementById("perkecil").addEventListener("click", function() {
    ukuranHuruf = Math.max(12, ukuranHuruf - 2);
    paragraf.style.fontSize = `${ukuranHuruf}px`;
});

document.getElementById("reset").addEventListener("click", function() {
    ukuranHuruf = ukuranSemula;
    paragraf.style.fontSize = `${ukuranSemula}px`;
});
