const daftarMahasiswa = [
    { nama: "Aditya Pratama", nilai: 80 },
    { nama: "Nadia Putri", nilai: 90 },
    { nama: "Rizky Maulana", nilai: 70 },
    { nama: "Siti Rahmawati", nilai: 85 },
    { nama: "Fajar Nugroho", nilai: 65 },
    { nama: "Intan Permata", nilai: 75 },
    { nama: "Dimas Saputra", nilai: 95 },
    { nama: "Aulia Safitri", nilai: 60 }
];
const nilaiUjian = daftarMahasiswa.map(mahasiswa => mahasiswa.nilai);
const daftarNilai = document.getElementById("daftarNilai");
const ringkasanNilai = document.getElementById("ringkasanNilai");

daftarNilai.innerHTML = daftarMahasiswa.map((mahasiswa, index) => `
    <tr>
        <th scope="row">${index + 1}</th>
        <td>${mahasiswa.nama}</td>
        <td>${mahasiswa.nilai}</td>
    </tr>
`).join("");

const nilaiTertinggi = Math.max(...nilaiUjian);
const nilaiTerendah = Math.min(...nilaiUjian);
const rataRata = nilaiUjian.reduce((total, nilai) => total + nilai, 0) / nilaiUjian.length;
const jumlahLulus = nilaiUjian.filter(nilai => nilai >= 75).length;
const ringkasan = [
    ["Nilai tertinggi", nilaiTertinggi],
    ["Nilai terendah", nilaiTerendah],
    ["Nilai rata-rata", rataRata.toFixed(2)],
    ["Jumlah mahasiswa lulus (nilai ≥ 75)", jumlahLulus]
];

ringkasanNilai.innerHTML = ringkasan.map(([keterangan, hasil]) => `
    <tr>
        <th scope="row">${keterangan}</th>
        <td>${hasil}</td>
    </tr>
`).join("");
