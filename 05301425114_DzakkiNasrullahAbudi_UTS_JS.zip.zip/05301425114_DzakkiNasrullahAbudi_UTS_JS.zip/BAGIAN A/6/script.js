let hasil = "";

for (let i = 1; i <= 50; i++) {
    if (i % 3 === 0 && i % 5 === 0) {
        hasil += "FizzBuzz<br>";
    } else if (i % 3 === 0) {
        hasil += "Fizz<br>";
    } else if (i % 5 === 0) {
        hasil += "Buzz<br>";
    } else {
        hasil += i + "<br>";
    }
}

document.getElementById("hasil").innerHTML = hasil;
